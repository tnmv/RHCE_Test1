# Ansible Collection - coursedepartment.nginx

Documentation for the collection.